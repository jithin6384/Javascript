'use strict';
if(screen.width < 750) {

    const rowCategory = document.querySelector('.row-category');
const rowCategory2 = document.querySelector('.row-category2');
const rowCategory3 = document.querySelector('.row-category3');
//newly added step 1
const rowCategory4 = document.querySelector('.malignancies');
const rowCategory5 = document.querySelector('.solidTumors');
const rowCategory6 = document.querySelector('.therapeuticCategory');

const leftConnector = 'left-connector';
const rightConnector = 'right-connector';
const topConnector = 'connector-nine';
const toprightConnector = 'top-right-connector';
let clickedCategory = false;

let items = [];
// {title: ['TAK-981', '']},
// ];

let itemsPhase2 = [];
let itemsPhase3 = [];
for(let i = 1; i <= 15; i++) {
    items.push({title: [`TAK-98${i}`, '']})
}

for(let i = 1; i <= 6; i++) {
    itemsPhase2.push({title: ['TAK-902', 'Relapsed/Refractory C-Cell']})
}

for(let i = 1; i <= 5; i++) {
    itemsPhase3.push({title: ['TAK-901', 'Relapsed/Refractory D-Cell']})
}


// step 2
let malignancies = [];
let solidTumors = [];

for(let i = 1; i <= 8; i++){
    malignancies.push({title: ['TAK-007', 'Malignancies B-Cell'] })
}

for(let i = 1; i <= 8; i++){
    solidTumors.push({title: ['TAK-981', 'Malignancies A-Cell'] })
}


let categorySelect = {'Lymphomas': []};

for(let i = 1; i <= 4; i++){
    categorySelect['Lymphomas'].push({title: ['TAK-981', 'Lymphomas A-Cell'] })
}

//display connector
const getConnectors = function(i) {
    if(i == 4 ){
        return {4: toprightConnector}
    }

}




}